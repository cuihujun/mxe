class ExampleIDNA {
    public static void main(String[] args) {
	System.out.println(new IDNA().toAscii(args[0]));
    }
}
