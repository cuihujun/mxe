/* Dummy file to satisfy source file dependencies on Windows platform */
